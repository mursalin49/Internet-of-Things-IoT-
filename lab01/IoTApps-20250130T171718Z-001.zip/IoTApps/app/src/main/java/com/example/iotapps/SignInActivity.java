package com.example.iotapps;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SignInActivity extends AppCompatActivity {

    EditText edtSignUIEmail, edtSignUIPasswrd;
    Button btnSignUISignIN, btnSignUIRegister;

    // Write a message to the database
    FirebaseDatabase database = FirebaseDatabase.getInstance();

    DatabaseReference uEmailRef = database.getReference("User").child("Email");
    DatabaseReference uPasswordRef = database.getReference("User").child("Password");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_in);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edtSignUIEmail = findViewById(R.id.editTextSignUIEmail);
        edtSignUIPasswrd = findViewById(R.id.editTextSignUIPassword);

        btnSignUISignIN = findViewById(R.id.buttonSignUILogIN);
        btnSignUIRegister = findViewById(R.id.buttonSignUISignUp);


        String databaseSavedEmail[] = new String[1];
        String databaseSavedPassword [] = new String[1];



        // Read Saved User Email from the database
        uEmailRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                databaseSavedEmail[0]  = dataSnapshot.getValue(String.class);
                Log.d(TAG, "Value is: " + databaseSavedEmail[0]);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });



        // Read Saved User Password from the database
        uPasswordRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                databaseSavedPassword[0]  = dataSnapshot.getValue(String.class);
                Log.d(TAG, "Value is: " + databaseSavedPassword[0]);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });


        btnSignUISignIN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userTypeSignINEmail = edtSignUIEmail.getText().toString().trim();
                String userTypeSignINPass = edtSignUIPasswrd.getText().toString().trim();
                if(userTypeSignINEmail.isEmpty() || userTypeSignINPass.isEmpty())
                {
                    Toast.makeText(SignInActivity.this, "One Or more fields are empty," +
                            "Kindly input all fields", Toast.LENGTH_SHORT).show();
                }
                else {
                    if(databaseSavedEmail[0].equals(userTypeSignINEmail) && databaseSavedPassword[0].equals(userTypeSignINPass))
                    {
                        startActivity(new Intent(SignInActivity.this, MainFunctionApp.class));
                    }
                    else {

                        Toast.makeText(SignInActivity.this, "Email Or password is incorrect," +
                                "Kindly input correct Email and Password", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });

        btnSignUIRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignInActivity.this, MainActivity.class));
            }
        });

    }
}